let getHomePage = (req, res) => {
  return res.send('hello world from homeController');
};

// object: {
//     key: '',
//     value: ''
// }
module.exports = {
  getHomePage: getHomePage,
};
